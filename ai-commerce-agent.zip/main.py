from fastapi import FastAPI
from schemas import ProductInput, AgentResult
from agents import CommerceAgentSystem
from db import init_db, save_task
import json

app = FastAPI()

init_db()
agent_system = CommerceAgentSystem()


@app.get("/")
def home():
    return {"status": "running"}


@app.post("/generate", response_model=AgentResult)
def generate_content(data: ProductInput):
    result = agent_system.run(data)

    save_task(
        product_name=data.product_name,
        category=data.category,
        platform=data.platform,
        result=json.dumps(result, ensure_ascii=False)
    )

    return result
