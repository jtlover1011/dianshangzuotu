from sqlalchemy import create_engine, Column, Integer, String, Text, DateTime
from sqlalchemy.orm import declarative_base, sessionmaker
from datetime import datetime

engine = create_engine("sqlite:///commerce_agent.db")
SessionLocal = sessionmaker(bind=engine)

Base = declarative_base()


class AgentTask(Base):
    __tablename__ = "agent_tasks"

    id = Column(Integer, primary_key=True, index=True)
    product_name = Column(String(255))
    category = Column(String(255))
    platform = Column(String(100))
    result = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)


def init_db():
    Base.metadata.create_all(bind=engine)


def save_task(product_name: str, category: str, platform: str, result: str):
    db = SessionLocal()
    task = AgentTask(
        product_name=product_name,
        category=category,
        platform=platform,
        result=result
    )
    db.add(task)
    db.commit()
    db.close()
