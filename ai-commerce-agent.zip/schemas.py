from pydantic import BaseModel
from typing import List, Optional


class ProductInput(BaseModel):
    product_name: str
    category: str
    platform: str
    price_positioning: str
    product_features: List[str]
    target_users: Optional[str] = None
    competitor_notes: Optional[str] = None


class AgentResult(BaseModel):
    product_analysis: str
    selling_points: str
    main_image_prompts: str
    detail_page_plan: str
    optimization_advice: str
