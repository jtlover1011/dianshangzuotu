from schemas import ProductInput
from llm import call_llm


class ProductUnderstandingAgent:
    def run(self, data: ProductInput) -> str:
        system_prompt = "你是电商商品分析专家"
        user_prompt = f"商品信息：{data}"
        return call_llm(system_prompt, user_prompt)


class SellingPointAgent:
    def run(self, data: ProductInput, product_analysis: str) -> str:
        system_prompt = "你是电商卖点生成专家"
        user_prompt = f"{product_analysis}"
        return call_llm(system_prompt, user_prompt)


class MainImagePromptAgent:
    def run(self, data: ProductInput, selling_points: str) -> str:
        system_prompt = "你是电商图片提示词专家"
        user_prompt = f"{selling_points}"
        return call_llm(system_prompt, user_prompt)


class DetailPageAgent:
    def run(self, data: ProductInput, selling_points: str) -> str:
        system_prompt = "你是详情页设计专家"
        user_prompt = f"{selling_points}"
        return call_llm(system_prompt, user_prompt)


class ConversionOptimizationAgent:
    def run(self, data: ProductInput, product_analysis: str, selling_points: str, image_prompts: str, detail_plan: str) -> str:
        system_prompt = "你是转化优化专家"
        user_prompt = f"{detail_plan}"
        return call_llm(system_prompt, user_prompt)


class CommerceAgentSystem:
    def __init__(self):
        self.product_agent = ProductUnderstandingAgent()
        self.selling_agent = SellingPointAgent()
        self.image_agent = MainImagePromptAgent()
        self.detail_agent = DetailPageAgent()
        self.optimize_agent = ConversionOptimizationAgent()

    def run(self, data: ProductInput):
        product_analysis = self.product_agent.run(data)
        selling_points = self.selling_agent.run(data, product_analysis)
        image_prompts = self.image_agent.run(data, selling_points)
        detail_plan = self.detail_agent.run(data, selling_points)
        optimization = self.optimize_agent.run(data, product_analysis, selling_points, image_prompts, detail_plan)

        return {
            "product_analysis": product_analysis,
            "selling_points": selling_points,
            "main_image_prompts": image_prompts,
            "detail_page_plan": detail_plan,
            "optimization_advice": optimization
        }
